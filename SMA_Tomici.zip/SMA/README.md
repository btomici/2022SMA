# Note Me
#### A Simple Note Taking Android App
You Can ADD,VIEW,EDIT and UPDATE the note. The Notes are Stored in SQLite Database. This is perfect example to get hands on Database operation on SQLite for android. 

# DEMOS
